## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.align = "center",
  fig.retina = 2,
  out.width = "100%"
)

## ----load---------------------------------------------------------------------
library(interactmeta)
library(ggplot2)
library(patchwork)

## ----data---------------------------------------------------------------------
age_es <- escalc(measure = "IRR", yi = yi, vi = vi, data = age)

## ----fit, cache = TRUE--------------------------------------------------------
# Article WIP scales (arXiv:2606.23968); package defaults are bayesmeta improper.
fit <- cam(
  age_es,
  reference = "Younger",
  tau.prior = function(tau) bayesmeta::dhalfnormal(tau, scale = 0.5),
  tau.interaction.prior = function(tau) bayesmeta::dhalfnormal(tau, scale = 0.1)
)

## ----forest-fp, include = FALSE-----------------------------------------------
fp <- forestplot(fit, exponentiate = TRUE)

## ----forest, fig.height = 6, fig.width = 7, fig.cap = "Grey diamonds are trial reconstructions; navy diamonds are pooled."----
fp

## ----helpers, include = FALSE-------------------------------------------------
pal <- interactmeta_palette()
col_m <- unname(pal[["teal"]])
col_g <- unname(pal[["navy_mid"]])
col_mu <- unname(pal[["navy"]])
col_obs <- "#000000"
col_zero <- "#D0D0D0"
col_guide <- "#7A7A7A"

trial <- "ADVANCE"
ref <- "Younger"
nonref <- "Older"
z95 <- stats::qnorm(0.975)

tq <- cam_trial_quantities(fit)
adv <- tq[as.character(tq$trial) == trial, , drop = FALSE]
pi_j <- unname(adv$pi)
m_obs <- unname(adv$m)
g_obs <- unname(adv$g)
v_m <- unname(adv$v_m)
v_g <- unname(adv$v_g)

adv_dat <- as.data.frame(age_es)
adv_dat <- adv_dat[as.character(adv_dat$trial) == trial, , drop = FALSE]
y_A <- as.numeric(adv_dat$yi[as.character(adv_dat$subgroup) == ref])[[1L]]
y_B <- as.numeric(adv_dat$yi[as.character(adv_dat$subgroup) == nonref])[[1L]]
v_A <- as.numeric(adv_dat$vi[as.character(adv_dat$subgroup) == ref])[[1L]]
v_B <- as.numeric(adv_dat$vi[as.character(adv_dat$subgroup) == nonref])[[1L]]

interval_row <- function(y, estimate, se, colour, math) {
  data.frame(
    y = y,
    estimate = estimate,
    lci = estimate - z95 * se,
    uci = estimate + z95 * se,
    colour = colour,
    math = math,
    stringsAsFactors = FALSE
  )
}

span_of <- function(..., pad = 0.18, min_pad = 0.08) {
  xs <- unlist(list(...), use.names = FALSE)
  r <- range(xs, na.rm = TRUE)
  extra <- diff(r) * pad
  if (!is.finite(extra) || extra < min_pad) extra <- min_pad
  c(r[[1L]] - extra, r[[2L]] + extra)
}

density_frame <- function(dens, from, to, n = 400L) {
  x <- seq(from, to, length.out = n)
  data.frame(x = x, density = as.numeric(dens(x)))
}

label_at_mode <- function(df, label) {
  i <- which.max(df$density)
  data.frame(
    x = df$x[[i]],
    density = df$density[[i]],
    label = label,
    stringsAsFactors = FALSE
  )
}

plot_intervals <- function(dat, xlim = NULL) {
  dat$y <- factor(dat$y, levels = rev(unique(dat$y)))
  xmax <- max(dat$uci, na.rm = TRUE)
  p <- ggplot(dat, aes(estimate, y, colour = colour)) +
    geom_vline(
      xintercept = 0,
      colour = col_zero,
      linewidth = 0.35
    ) +
    geom_pointrange(shape = 15,
      aes(xmin = lci, xmax = uci),
      linewidth = 0.55,
      size = 1.15
    ) +
    geom_text(
      aes(x = xmax, label = math),
      parse = TRUE,
      hjust = -0.2,
      size = 3.6
    ) +
    scale_colour_identity() +
    scale_y_discrete(expand = expansion(add = 0.7)) +
    labs(x = "Log incidence-rate ratio", y = NULL) +
    interactmeta_theme_report(variant = "minimal") +
    theme(
      axis.ticks.y = element_blank(),
      axis.line.y = element_blank(),
      plot.margin = margin(6, 40, 6, 8, unit = "pt")
    )
  if (is.null(xlim)) {
    xlim <- span_of(dat$lci, dat$uci, 0, pad = 0.12)
  }
  p + coord_cartesian(xlim = xlim, clip = "off")
}

plot_density_panels <- function(dens,
                                band,
                                labels,
                                xlim,
                                ncol = 1L,
                                extra_vlines = NULL,
                                scales = "fixed") {
  dens$panel <- factor(dens$panel, levels = unique(dens$panel))
  band$panel <- factor(band$panel, levels = levels(dens$panel))
  labels$panel <- factor(labels$panel, levels = levels(dens$panel))
  ribbon <- merge(dens, band, by = "panel")
  ribbon <- ribbon[ribbon$x >= ribbon$lower & ribbon$x <= ribbon$upper, ]
  p <- ggplot(dens, aes(x, density, colour = colour, fill = colour)) +
    geom_vline(xintercept = 0, colour = col_zero, linewidth = 0.35) +
    geom_ribbon(
      data = ribbon,
      aes(ymin = 0, ymax = density),
      alpha = 0.22,
      colour = NA
    ) +
    geom_area(alpha = 0.10, colour = NA) +
    geom_line(linewidth = 0.7) +
    geom_text(
      data = labels,
      aes(x = x, y = density, label = label, colour = colour),
      parse = TRUE,
      hjust = -0.08,
      vjust = -0.35,
      size = 3.6,
      inherit.aes = FALSE
    ) +
    scale_colour_identity() +
    scale_fill_identity() +
    scale_x_continuous(expand = expansion(mult = c(0.02, 0.22))) +
    coord_cartesian(xlim = xlim, clip = "off") +
    facet_wrap(~panel, ncol = ncol, scales = scales) +
    labs(x = "Log incidence-rate ratio", y = NULL) +
    interactmeta_theme_report(variant = "density") +
    theme(
      strip.background = element_blank(),
      strip.text = element_blank(),
      plot.margin = margin(10, 22, 6, 8, unit = "pt"),
      panel.spacing = unit(0.9, "lines")
    )
  if (!is.null(extra_vlines) && nrow(extra_vlines)) {
    extra_vlines$panel <- factor(
      extra_vlines$panel,
      levels = levels(dens$panel)
    )
    p <- p +
      geom_vline(
        data = extra_vlines,
        aes(xintercept = xint, colour = colour),
        linetype = "22",
        linewidth = 0.4,
        inherit.aes = FALSE
      )
  }
  p
}

plot_joint_xy <- function(grid, points, xlab, ylab,
                          iso = NULL, iso_hi = NULL,
                          xlim = NULL, ylim = NULL,
                          fill_limits = NULL,
                          equal = FALSE) {
  p <- ggplot(grid, aes(x, y, fill = z)) +
    geom_raster(interpolate = TRUE) +
    scale_fill_gradient(
      low = "#FFFFFF",
      high = col_mu,
      guide = "none",
      limits = fill_limits,
      oob = scales::squish
    ) +
    geom_hline(yintercept = 0, colour = col_zero, linewidth = 0.3) +
    geom_vline(xintercept = 0, colour = col_zero, linewidth = 0.3)
  if (!is.null(iso) && nrow(iso)) {
    p <- p +
      geom_line(
        data = iso,
        aes(x, y, group = zlab),
        inherit.aes = FALSE,
        colour = col_guide,
        linewidth = 0.3,
        linetype = "22"
      )
  }
  if (!is.null(iso_hi) && nrow(iso_hi)) {
    p <- p +
      geom_line(
        data = iso_hi,
        aes(x, y, group = zlab),
        inherit.aes = FALSE,
        colour = col_mu,
        linewidth = 0.55
      )
  }
  p +
    geom_point(
      data = points,
      aes(x, y),
      inherit.aes = FALSE,
      colour = "#FFFFFF",
      size = 3.8
    ) +
    geom_point(
      data = points,
      aes(x, y, shape = shape, colour = colour),
      inherit.aes = FALSE,
      size = 2.5
    ) +
    scale_shape_identity() +
    scale_colour_identity() +
    labs(x = xlab, y = ylab) +
    interactmeta_theme_report(variant = "minimal") +
    theme(plot.margin = margin(6, 8, 6, 6, unit = "pt")) +
    if (isTRUE(equal)) {
      coord_fixed(xlim = xlim, ylim = ylim, expand = FALSE, ratio = 1)
    } else {
      coord_cartesian(xlim = xlim, ylim = ylim, expand = FALSE)
    }
}

## ----observe-fig, fig.height = 2.4, echo = FALSE, fig.cap = "Quoted subgroup intervals for ADVANCE."----
obs_int <- rbind(
  interval_row("Younger", y_A, sqrt(v_A), col_obs, "y[A]"),
  interval_row("Older", y_B, sqrt(v_B), col_obs, "y[B]")
)
plot_intervals(obs_int)

## ----rotate-pi----------------------------------------------------------------
data.frame(
  trial = trial,
  pi = round(pi_j, 3),
  y_A = round(y_A, 3),
  y_B = round(y_B, 3),
  m = round(m_obs, 3),
  g = round(g_obs, 3)
)

## ----rotate-fig, fig.height = 3.3, echo = FALSE, fig.cap = "Quoted $y_A$, $y_B$ and the rotated pair $(m,g)$."----
rot_int <- rbind(
  interval_row("Younger", y_A, sqrt(v_A), col_obs, "y[A]"),
  interval_row("Older", y_B, sqrt(v_B), col_obs, "y[B]"),
  interval_row("overall", m_obs, sqrt(v_m), col_m, "italic(m)"),
  interval_row("interaction", g_obs, sqrt(v_g), col_g, "italic(g)")
)
plot_intervals(rot_int)

## ----shrink-native, include = FALSE-------------------------------------------
native <- native_fit(fit)
overall <- native$overall
interaction <- native$interaction

## ----shrink-dens, include = FALSE---------------------------------------------
trial <- "ADVANCE"
dens_m <- function(x, log = FALSE) {
  as.numeric(overall$dshrink(theta = x, which = trial, log = log))
}
cdf_m <- function(x) {
  as.numeric(overall$pshrink(theta = x, which = trial))
}
dens_g <- function(x, log = FALSE) {
  as.numeric(interaction$dposterior(mu = x, individual = trial, log = log))
}
cdf_g <- function(x) {
  as.numeric(interaction$pposterior(mu = x, individual = trial))
}

## ----shrink-build, include = FALSE--------------------------------------------
qs <- c(0.025, 0.5, 0.975)
q_m <- as.numeric(overall$qshrink(p = qs, which = trial))
q_g <- as.numeric(interaction$qposterior(mu.p = qs, individual = trial))

xlim_mg <- span_of(q_m, q_g, m_obs, g_obs, 0)
df_m <- density_frame(dens_m, xlim_mg[[1L]], xlim_mg[[2L]])
df_g <- density_frame(dens_g, xlim_mg[[1L]], xlim_mg[[2L]])

## ----shrink-fig, fig.height = 3.6, echo = FALSE, fig.cap = "ADVANCE shrinkage posteriors for $m$ and $g$. Dashed ticks mark the quoted values."----
shrink_dens <- rbind(
  data.frame(df_m, panel = "m", colour = col_m),
  data.frame(df_g, panel = "g", colour = col_g)
)
shrink_band <- data.frame(
  panel = c("m", "g"),
  lower = c(q_m[[1L]], q_g[[1L]]),
  upper = c(q_m[[3L]], q_g[[3L]])
)
shrink_lab <- rbind(
  data.frame(label_at_mode(df_m, "italic(m)"), panel = "m", colour = col_m),
  data.frame(label_at_mode(df_g, "italic(g)"), panel = "g", colour = col_g)
)
shrink_ticks <- data.frame(
  panel = c("m", "g"),
  xint = c(m_obs, g_obs),
  linetype = "22",
  colour = col_guide,
  linewidth = 0.4
)
plot_density_panels(
  shrink_dens,
  shrink_band,
  shrink_lab,
  xlim = xlim_mg,
  ncol = 2L,
  extra_vlines = shrink_ticks,
  scales = "free_y"
)

## ----scale-build, include = FALSE---------------------------------------------
dens_minus_pi_g <- function(x, log = FALSE) {
  z <- x / (-pi_j)
  d <- dens_g(z, log = log)
  if (isTRUE(log)) {
    d - log(abs(pi_j))
  } else {
    d / abs(pi_j)
  }
}
cdf_minus_pi_g <- function(x) {
  1 - cdf_g(x / (-pi_j))
}
q_minus_pi_g <- -pi_j * rev(q_g)

xlim_g <- span_of(q_g, g_obs, 0)
xlim_ng <- span_of(q_minus_pi_g, -pi_j * g_obs, 0)
df_g_before <- density_frame(dens_g, xlim_g[[1L]], xlim_g[[2L]])
df_ng <- density_frame(dens_minus_pi_g, xlim_ng[[1L]], xlim_ng[[2L]])

## ----scale-fig, fig.height = 3.6, echo = FALSE, fig.cap = "Interaction shrinkage before and after the map $g\\mapsto -\\pi_j g$."----
scale_dens <- rbind(
  data.frame(df_g_before, panel = "before", colour = col_g),
  data.frame(df_ng, panel = "after", colour = col_g)
)
scale_band <- data.frame(
  panel = c("before", "after"),
  lower = c(q_g[[1L]], q_minus_pi_g[[1L]]),
  upper = c(q_g[[3L]], q_minus_pi_g[[3L]])
)
scale_lab <- rbind(
  data.frame(
    label_at_mode(df_g_before, "italic(g)"),
    panel = "before",
    colour = col_g
  ),
  data.frame(
    label_at_mode(df_ng, "-pi[j]*italic(g)"),
    panel = "after",
    colour = col_g
  )
)
plot_density_panels(
  scale_dens,
  scale_band,
  scale_lab,
  xlim = range(c(xlim_g, xlim_ng)),
  ncol = 2L
)

## ----convolve-build-----------------------------------------------------------
conv_A <- bayesmeta::convolve(
  dens1 = dens_m,
  dens2 = dens_minus_pi_g,
  cdf1 = cdf_m,
  cdf2 = cdf_minus_pi_g,
  delta = 0.01,
  epsilon = 1e-4
)

## ----convolve-prep, include = FALSE-------------------------------------------
q_conv_A <- as.numeric(conv_A$quantile(qs))
xlim_conv <- span_of(q_m, q_minus_pi_g, q_conv_A, 0)
df_m_c <- density_frame(dens_m, xlim_conv[[1L]], xlim_conv[[2L]])
df_ng_c <- density_frame(dens_minus_pi_g, xlim_conv[[1L]], xlim_conv[[2L]])
df_A <- density_frame(conv_A$density, xlim_conv[[1L]], xlim_conv[[2L]])

## ----convolve-fig, fig.height = 6.4, echo = FALSE, fig.cap = "Convolution of overall shrinkage $m$ with $-\\pi_j g$ yields the Younger reconstruction $\\mu_A$."----
conv_dens <- rbind(
  data.frame(df_m_c, panel = "m", colour = col_m),
  data.frame(df_ng_c, panel = "ng", colour = col_g),
  data.frame(df_A, panel = "A", colour = col_mu)
)
conv_band <- data.frame(
  panel = c("m", "ng", "A"),
  lower = c(q_m[[1L]], q_minus_pi_g[[1L]], q_conv_A[[1L]]),
  upper = c(q_m[[3L]], q_minus_pi_g[[3L]], q_conv_A[[3L]])
)
conv_lab <- rbind(
  data.frame(label_at_mode(df_m_c, "italic(m)"), panel = "m", colour = col_m),
  data.frame(
    label_at_mode(df_ng_c, "-pi[j]*italic(g)"),
    panel = "ng",
    colour = col_g
  ),
  data.frame(label_at_mode(df_A, "mu[A]"), panel = "A", colour = col_mu)
)
plot_density_panels(
  conv_dens,
  conv_band,
  conv_lab,
  xlim = xlim_conv,
  ncol = 1L
)

## ----joint-build, include = FALSE---------------------------------------------
lim_mg <- span_of(q_m, q_g, m_obs, g_obs, 0)
n_j <- 100L
m_seq <- seq(lim_mg[[1L]], lim_mg[[2L]], length.out = n_j)
g_seq <- m_seq
df_m_j <- density_frame(dens_m, lim_mg[[1L]], lim_mg[[2L]], n = n_j)
df_g_j <- density_frame(dens_g, lim_mg[[1L]], lim_mg[[2L]], n = n_j)
grid_mg <- expand.grid(x = m_seq, y = g_seq, KEEP.OUT.ATTRS = FALSE)
grid_mg$z <- approx(
  df_m_j$x, df_m_j$density, xout = grid_mg$x, rule = 2
)$y * approx(
  df_g_j$x, df_g_j$density, xout = grid_mg$y, rule = 2
)$y
iso_z <- pretty(c(y_A - 0.35, y_A + 0.35), n = 4L)
iso_mg <- do.call(rbind, lapply(iso_z, function(z) {
  data.frame(x = m_seq, y = (m_seq - z) / pi_j, zlab = z)
}))
iso_yA <- data.frame(
  x = m_seq,
  y = (m_seq - y_A) / pi_j,
  zlab = y_A
)
m_shr <- q_m[[2L]]
g_shr <- q_g[[2L]]
muA_shr <- m_shr - pi_j * g_shr
muB_shr <- m_shr + (1 - pi_j) * g_shr
xlim_A_j <- span_of(
  y_A, muA_shr,
  q_m[[1L]] - pi_j * q_g[[3L]],
  q_m[[3L]] - pi_j * q_g[[1L]]
)
xlim_B_j <- span_of(
  y_B, muB_shr,
  q_m[[1L]] + (1 - pi_j) * q_g[[1L]],
  q_m[[3L]] + (1 - pi_j) * q_g[[3L]]
)
A_seq <- seq(xlim_A_j[[1L]], xlim_A_j[[2L]], length.out = n_j)
B_seq <- seq(xlim_B_j[[1L]], xlim_B_j[[2L]], length.out = n_j)
grid_ab <- expand.grid(x = A_seq, y = B_seq, KEEP.OUT.ATTRS = FALSE)
m_ab <- (1 - pi_j) * grid_ab$x + pi_j * grid_ab$y
g_ab <- grid_ab$y - grid_ab$x
grid_ab$z <- approx(
  df_m_j$x, df_m_j$density, xout = m_ab, rule = 2
)$y * approx(
  df_g_j$x, df_g_j$density, xout = g_ab, rule = 2
)$y
iso_ab <- do.call(rbind, lapply(iso_z, function(z) {
  data.frame(x = c(z, z), y = xlim_B_j, zlab = z)
}))
iso_yA_ab <- data.frame(
  x = c(y_A, y_A),
  y = xlim_B_j,
  zlab = y_A
)
pt_mg <- data.frame(
  x = c(m_obs, m_shr),
  y = c(g_obs, g_shr),
  shape = c(15, 18),
  colour = c(col_obs, col_m),
  stringsAsFactors = FALSE
)
pt_ab <- data.frame(
  x = c(y_A, muA_shr),
  y = c(y_B, muB_shr),
  shape = c(15, 18),
  colour = c(col_obs, col_m),
  stringsAsFactors = FALSE
)
zlim <- range(c(grid_mg$z, grid_ab$z), na.rm = TRUE)

## ----joint-fig, fig.height = 4.2, echo = FALSE, fig.cap = "Same joint, two coordinates. Left: $p(m)p(g)$. Right: inverse rotation. Dashed: $\\mu_A$ level sets; solid: quoted $y_A$. Square: quoted pair; diamond: shrinkage medians."----
p_mg <- plot_joint_xy(
  grid_mg,
  pt_mg,
  xlab = expression(italic(m)),
  ylab = expression(italic(g)),
  iso = iso_mg,
  iso_hi = iso_yA,
  xlim = lim_mg,
  ylim = lim_mg,
  fill_limits = zlim,
  equal = TRUE
)
p_ab <- plot_joint_xy(
  grid_ab,
  pt_ab,
  xlab = expression(mu[A]),
  ylab = expression(mu[B]),
  iso = iso_ab,
  iso_hi = iso_yA_ab,
  xlim = xlim_A_j,
  ylim = xlim_B_j,
  fill_limits = zlim
)
p_mg + p_ab

## ----product-grid-prep, include = FALSE---------------------------------------
gm_m <- fit$latent$m[[trial]]$gm
gm_g <- fit$latent$g[[trial]]$gm
n_m <- length(gm_m$mean)
n_g <- length(gm_g$mean)
i_ov <- rep(seq_len(n_m), each = n_g)
i_int <- rep(seq_len(n_g), times = n_m)
lab_pair <- "DIRECT pair"
lab_obs <- "Quoted (m, g)"
lab_mix <- "Mixture median"
lab_slice <- "mu[A] level set"
lab_yA <- "Quoted y[A]"
nodes <- data.frame(
  x = gm_m$mean[i_ov],
  y = gm_g$mean[i_int],
  w = gm_m$weight[i_ov] * gm_g$weight[i_int],
  layer = lab_pair,
  stringsAsFactors = FALSE
)
nodes <- nodes[order(nodes$w), , drop = FALSE]
pt_grid <- data.frame(
  x = pt_mg$x,
  y = pt_mg$y,
  layer = c(lab_obs, lab_mix),
  stringsAsFactors = FALSE
)
layer_lvls <- c(lab_pair, lab_obs, lab_mix)
nodes$layer <- factor(nodes$layer, levels = layer_lvls)
pt_grid$layer <- factor(pt_grid$layer, levels = layer_lvls)
iso_mg$lin <- factor(lab_slice, levels = c(lab_slice, lab_yA))
iso_yA$lin <- factor(lab_yA, levels = c(lab_slice, lab_yA))
lim_grid <- span_of(lim_mg, nodes$x, nodes$y)

## ----product-grid-fig, fig.height = 4.6, echo = FALSE, fig.cap = "DIRECT product grid on $p(m)p(g)$. Gold: $(\\tau_q,\\tau_{\\gamma,r})$ at $(m_q,g_r)$, area $w_q v_r$."----
ggplot(grid_mg, aes(x, y, fill = z)) +
  geom_raster(interpolate = TRUE) +
  scale_fill_gradient(
    low = "#FFFFFF",
    high = col_mu,
    guide = "none",
    limits = zlim,
    oob = scales::squish
  ) +
  geom_hline(yintercept = 0, colour = col_zero, linewidth = 0.3) +
  geom_vline(xintercept = 0, colour = col_zero, linewidth = 0.3) +
  geom_line(
    data = iso_mg,
    aes(x, y, group = zlab, linetype = lin),
    inherit.aes = FALSE,
    colour = col_guide,
    linewidth = 0.3
  ) +
  geom_line(
    data = iso_yA,
    aes(x, y, group = zlab, linetype = lin),
    inherit.aes = FALSE,
    colour = col_mu,
    linewidth = 0.55
  ) +
  geom_point(
    data = nodes,
    aes(x, y, size = w, colour = layer, shape = layer),
    inherit.aes = FALSE,
    alpha = 0.45,
    stroke = 0
  ) +
  geom_point(
    data = pt_grid,
    aes(x, y),
    inherit.aes = FALSE,
    colour = "#FFFFFF",
    size = 3.8,
    show.legend = FALSE
  ) +
  geom_point(
    data = pt_grid,
    aes(x, y, colour = layer, shape = layer),
    inherit.aes = FALSE,
    size = 2.5
  ) +
  scale_colour_manual(
    name = NULL,
    values = setNames(c(col_g, col_obs, col_m), layer_lvls)
  ) +
  scale_shape_manual(
    name = NULL,
    values = setNames(c(16, 15, 18), layer_lvls)
  ) +
  scale_size_area(name = expression(w[q]*v[r]), max_size = 3.2) +
  scale_linetype_manual(
    name = NULL,
    values = setNames(c("22", "solid"), c(lab_slice, lab_yA)),
    labels = c(
      expression(mu[A]~"level set"),
      expression("Quoted"~y[A])
    )
  ) +
  guides(
    colour = guide_legend(
      order = 1,
      override.aes = list(size = 2.4, alpha = 1, stroke = 0)
    ),
    shape = guide_legend(order = 1),
    size = guide_legend(order = 2),
    linetype = guide_legend(
      order = 3,
      override.aes = list(
        colour = c(col_guide, col_mu),
        linewidth = c(0.35, 0.55)
      )
    )
  ) +
  labs(x = expression(italic(m)), y = expression(italic(g))) +
  interactmeta_theme_report(variant = "minimal") +
  theme(
    plot.margin = margin(6, 8, 6, 6, unit = "pt"),
    legend.position = "right"
  ) +
  coord_fixed(xlim = lim_grid, ylim = lim_grid, expand = FALSE, ratio = 1)

