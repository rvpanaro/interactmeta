## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.align = "center",
  fig.retina = 2,
  out.width = "100%"
)

## ----load---------------------------------------------------------------------
library(interactmeta)

## ----data---------------------------------------------------------------------
head(respire_age[, c("trial", "subgroup", "hr", "yi", "vi")])

## ----fit, cache = TRUE--------------------------------------------------------
fit_da <- da(respire_age, reference = "<65")
fit_ad <- ad(respire_age, reference = "<65")
fit_sw <- swada(respire_age, reference = "<65")
fit_cams <- cam(respire_age, reference = "<65", method = "REML")

## ----compare-int--------------------------------------------------------------
compare_interactions(
  fit_da,
  fit_ad,
  fit_sw,
  fit_cams,
  exponentiate = TRUE
)

## ----compare-sg---------------------------------------------------------------
compare_subgroups(
  fit_da,
  fit_sw,
  fit_cams,
  exponentiate = TRUE
)

## ----weights------------------------------------------------------------------
compare_weights(fit_da, fit_ad, fit_sw)

## ----contribution, fig.height = 5---------------------------------------------
plot_contribution(fit_cams)

