## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.align = "center",
  fig.retina = 2,
  out.width = "100%",
  message = FALSE
)

## ----load---------------------------------------------------------------------
library(interactmeta)

## ----data---------------------------------------------------------------------
age_es <- escalc(measure = "IRR", yi = yi, vi = vi, data = age)

## ----fit, cache = TRUE--------------------------------------------------------
# Article WIP scales (arXiv:2606.23968): HN(0.5) overall, HN(0.1) interaction.
# Package defaults alone match bayesmeta (improper uniform / flat).
tau_m <- function(tau) bayesmeta::dhalfnormal(tau, scale = 0.5)
tau_g <- function(tau) bayesmeta::dhalfnormal(tau, scale = 0.1)
fit <- cam(
  age_es,
  reference = "Younger",
  tau.prior = tau_m,
  tau.interaction.prior = tau_g
)
fit_reml <- cam(age_es, reference = "Younger", engine = "metafor")
fit_ml <- cam(age_es, reference = "Younger", method = "ML")

## ----prior-fit, cache = TRUE--------------------------------------------------
fit_tau <- cam(
  respire_age,
  reference = "<65",
  tau.prior = function(tau) bayesmeta::dhalfnormal(tau, scale = 1)
)

## ----bayescam, cache = TRUE---------------------------------------------------
fit_bc <- bayescams(
  respire_age,
  reference = "<65",
  tau.prior = tau_m,
  tau.interaction.prior = tau_g
)
fit_bc$engine

## ----summary------------------------------------------------------------------
summary(fit)

## ----overall------------------------------------------------------------------
overall(fit, exponentiate = TRUE)

## ----heterogeneity------------------------------------------------------------
het <- heterogeneity(fit)
het

## ----heterogeneity-footnote---------------------------------------------------
heterogeneity_footnote(het)

## ----plot-het, fig.height = 4-------------------------------------------------
plot_heterogeneity(fit)

## ----het-gg, fig.height = 4---------------------------------------------------
plot_heterogeneity(fit_reml)

## ----forest-int, fig.height = 5.5---------------------------------------------
fp_int <- forestplot(fit, type = "interaction", exponentiate = TRUE)

## ----forest-ov, fig.height = 5.5----------------------------------------------
forestplot(fit, type = "overall", exponentiate = TRUE)

## ----forest-height------------------------------------------------------------
forestplot_height(fp_int, width = 8)[c("width", "height", "n_rows")]

## ----forest-draw, fig.height = 5.5--------------------------------------------
forestplot_draw(fp_int)

## ----forest-metafor, fig.height = 5.5-----------------------------------------
metafor::forest(fit, type = "interaction", exponentiate = TRUE)

## ----as-bayesmeta-------------------------------------------------------------
bm <- as_bayesmeta(
  y = c(-0.20, -0.10),
  sigma = c(0.20, 0.15),
  labels = c("T1", "T2"),
  mu = c(median = -0.15, lower = -0.40, upper = 0.10)
)
class(bm)

## ----shrinkage----------------------------------------------------------------
shrinkage(fit, format = "summary", exponentiate = TRUE)

## ----shrinkage-diag-----------------------------------------------------------
shrinkage_diagnostics(fit)

## ----shrinkage-comp-----------------------------------------------------------
names(shrinkage_components(fit))

## ----standardized-------------------------------------------------------------
standardized_trial_effects(fit, format = "summary", exponentiate = TRUE)

## ----observed-----------------------------------------------------------------
observed_effects(fit, type = "interaction")

## ----fitted-------------------------------------------------------------------
dim(fitted(fit, summary = FALSE))

## ----contribution, fig.height = 5---------------------------------------------
plot_contribution(fit, exponentiate = TRUE)

## ----traceplot, fig.height = 5.5----------------------------------------------
traceplot(fit, type = "interaction")

## ----traceplot-combined, fig.height = 5.5-------------------------------------
traceplot(fit, type = "combined")

## ----add-ifrac----------------------------------------------------------------
dat <- as.data.frame(age_es)
dat$reference <- "Younger"
head(add_ifrac_design(dat)[, c("trial", "subgroup", "precision", "ifrac_Older")])

## ----predict-if---------------------------------------------------------------
head(predict_cams_by_if(fit, resolution = 5, exponentiate = TRUE))

## ----tidy---------------------------------------------------------------------
tidy(subgroups(fit, exponentiate = TRUE))

## ----tidy-het-----------------------------------------------------------------
tidy(het)

## ----da-bayes, cache = TRUE---------------------------------------------------
fit_da_b <- da(respire_age, reference = "<65", engine = "bayesmeta")
fit_ad_b <- ad(respire_age, reference = "<65", engine = "bayesmeta")
fit_da_b$engine

## ----conventional-------------------------------------------------------------
fit_conv <- conventional(respire_age, reference = "<65")
fit_conv

## ----da-sw-cam----------------------------------------------------------------
fit_da <- da(respire_age, reference = "<65")
fit_sw <- swada(respire_age, reference = "<65")
fit_cams_r <- cam(respire_age, reference = "<65", engine = "metafor")

## ----plot-sg, fig.height = 4.5------------------------------------------------
plot_subgroups(fit_da, fit_sw, fit_cams_r, exponentiate = TRUE)

## ----compare-plot, fig.height = 4---------------------------------------------
ix <- compare_interactions(
  fit_da,
  ad(respire_age, reference = "<65"),
  fit_sw,
  fit_cams_r,
  exponentiate = TRUE
)
plot(ix)

## ----capabilities-------------------------------------------------------------
interactmeta_capability_matrix()

## ----log-hr-------------------------------------------------------------------
r1 <- respire_age[respire_age$trial == "RESPIRE 1" &
                    respire_age$subgroup == "<65", ]
log_hr_from_ci(
  hr = r1$hr,
  ci_lower = r1$ci_lower,
  ci_upper = r1$ci_upper,
  ci_level = r1$ci_level
)

## ----hr-from-log--------------------------------------------------------------
hr_ci_from_log(yi = r1$yi, sei = r1$sei, ci_level = r1$ci_level)

