## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.align = "center",
  fig.retina = 2,
  out.width = "100%"
)

## ----load---------------------------------------------------------------------
library(interactmeta)

## ----steroids-pattern---------------------------------------------------------
st <- steroids[steroids$n > 0, ]
table(st$trial, st$subgroup)

## ----steroids-fit, cache = TRUE-----------------------------------------------
steroids_es <- escalc(
  measure = "OR",
  ai = treat.events,
  bi = treat.total - treat.events,
  ci = cont.events,
  di = cont.total - cont.events,
  data = st
)
des <- ifrac(steroids_es, reference = "NIV")
fit_da_st <- da(des, reference = "NIV")
fit_ad_st <- ad(des, reference = "NIV")
fit_sw_st <- swada(des, reference = "NIV")
fit_cams_st <- cam(des, reference = "NIV", engine = "metafor")

## ----steroids-des-print-------------------------------------------------------
head(des)

## ----steroids-int-------------------------------------------------------------
compare_interactions(
  fit_da_st,
  fit_ad_st,
  fit_sw_st,
  fit_cams_st,
  exponentiate = TRUE
)

## ----steroids-weights---------------------------------------------------------
compare_weights(fit_da_st, fit_ad_st, fit_sw_st)

## ----steroids-ifrac-overall---------------------------------------------------
ifrac(fit_cams_st, ifrac = "overall")

## ----steroids-ifrac-interaction-----------------------------------------------
ifrac(fit_cams_st, ifrac = "interaction")

## ----steroids-forest-overall, fig.height = 6, fig.width = 8-------------------
forestplot(
  fit_cams_st,
  exponentiate = TRUE,
  ifrac = "overall"
)

## ----steroids-forest-interaction, fig.height = 6, fig.width = 8---------------
forestplot(
  fit_cams_st,
  exponentiate = TRUE,
  ifrac = "interaction"
)

## ----steroids-sg-overall------------------------------------------------------
subgroups(fit_cams_st, exponentiate = TRUE, ifrac = "overall")

## ----steroids-sg-interaction--------------------------------------------------
subgroups(fit_cams_st, exponentiate = TRUE, ifrac = "interaction")

