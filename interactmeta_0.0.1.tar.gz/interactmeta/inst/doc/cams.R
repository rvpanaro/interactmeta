## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.align = "center",
  fig.retina = 2,
  out.width = "100%"
)

## ----load---------------------------------------------------------------------
library(interactmeta)

## ----data---------------------------------------------------------------------
age_es <- escalc(measure = "IRR", yi = yi, vi = vi, data = age)
head(age_es)

## ----ifrac--------------------------------------------------------------------
age_if <- ifrac(age_es, reference = "Younger")

## ----ifrac-head---------------------------------------------------------------
head(age_if)

## ----fit, cache = TRUE--------------------------------------------------------
fit <- cams(
  age_es,
  reference = "Younger",
  tau.prior = function(tau) bayesmeta::dhalfnormal(tau, scale = 0.5),
  tau.interaction.prior = function(tau) bayesmeta::dhalfnormal(tau, scale = 0.1)
)

## ----fit-print----------------------------------------------------------------
fit

## ----estimands-interactions---------------------------------------------------
interactions(fit, exponentiate = TRUE)

## ----estimands-subgroups------------------------------------------------------
subgroups(fit, exponentiate = TRUE)

## ----estimands-combined-------------------------------------------------------
combined(fit, exponentiate = TRUE)

## ----plug-in------------------------------------------------------------------
subgroups(fit, contribution = 0.5, type = "Pooled", exponentiate = TRUE)

## ----forest, fig.height = 6---------------------------------------------------
forestplot(fit, exponentiate = TRUE)

## ----contribution, fig.height = 5---------------------------------------------
plot_contribution(fit, exponentiate = TRUE)

