## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE
)

## ----load---------------------------------------------------------------------
library(interactmeta)

## ----age-es-------------------------------------------------------------------
age_es <- escalc(measure = "IRR", yi = yi, vi = vi, data = age)

## ----fit-bayes, cache = TRUE--------------------------------------------------
# Article WIP scales (arXiv:2606.23968); package defaults are bayesmeta improper.
fit_cams_bayes <- cam(
  age_es,
  reference = "Younger",
  tau.prior = function(tau) bayesmeta::dhalfnormal(tau, scale = 0.5),
  tau.interaction.prior = function(tau) bayesmeta::dhalfnormal(tau, scale = 0.1)
)

## ----fit-freq, cache = TRUE---------------------------------------------------
fit_cams_freq <- cam(
  age_es,
  reference = "Younger",
  engine = "metafor"
)

## ----fit-print-bayes----------------------------------------------------------
fit_cams_bayes

## ----fit-print-freq-----------------------------------------------------------
fit_cams_freq

## ----compare-ifrac------------------------------------------------------------
compare_ifrac(fit_cams_bayes, fit_cams_freq, ifrac = "overall")

## ----compare-ifrac-interaction------------------------------------------------
compare_ifrac(
  fit_cams_bayes,
  fit_cams_freq,
  ifrac = "interaction"
)

## ----compare-sg---------------------------------------------------------------
compare_subgroups(
  fit_cams_bayes,
  fit_cams_freq,
  exponentiate = TRUE
)

## ----compare-combined---------------------------------------------------------
compare_combined(
  fit_cams_bayes,
  fit_cams_freq,
  exponentiate = TRUE
)

## ----compare-int--------------------------------------------------------------
compare_interactions(
  fit_cams_bayes,
  fit_cams_freq,
  exponentiate = TRUE
)

## ----compare-het--------------------------------------------------------------
compare_heterogeneity(fit_cams_bayes, fit_cams_freq)

