## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.align = "center",
  fig.retina = 2,
  out.width = "100%"
)

## ----load---------------------------------------------------------------------
library(interactmeta)

## ----age-data-----------------------------------------------------------------
data(age)
head(age)

## ----age-escalc---------------------------------------------------------------
age_es <- escalc(measure = "IRR", yi = age$yi, vi = age$vi, data = age)

## ----age-escalc-print---------------------------------------------------------
head(age_es)

## ----age-fit, cache = TRUE----------------------------------------------------
# Article WIP scales (arXiv:2606.23968); package defaults are bayesmeta improper.
tau_m <- function(tau) bayesmeta::dhalfnormal(tau, scale = 0.5)
tau_g <- function(tau) bayesmeta::dhalfnormal(tau, scale = 0.1)
fit_age <- cam(
  age_es,
  reference = "Younger",
  tau.prior = tau_m,
  tau.interaction.prior = tau_g
)

## ----age-forest, fig.width = 8, fig.height = 6--------------------------------
forestplot(fit_age, exponentiate = TRUE)

## ----edss-data----------------------------------------------------------------
data(edss)
head(edss[, c("trial", "subgroup", "n", "treatment", "yi")])

## ----edss-escalc--------------------------------------------------------------
edss_es <- escalc(measure = "IRR", yi = edss$yi, vi = edss$vi, data = edss)

## ----edss-es-print------------------------------------------------------------
head(edss_es)

## ----edss-fit, cache = TRUE---------------------------------------------------
fit_edss <- cam(
  edss_es,
  reference = "Lower",
  tau.prior = tau_m,
  tau.interaction.prior = tau_g
)

## ----edss-forest, fig.width = 8, fig.height = 6-------------------------------
forestplot(fit_edss, exponentiate = TRUE)

## ----steroids-data------------------------------------------------------------
data(steroids)
head(steroids)

## ----steroids-escalc----------------------------------------------------------
steroids_es <- escalc(
  measure = "OR",
  ai = treat.events,
  bi = treat.total - treat.events,
  ci = cont.events,
  di = cont.total - cont.events,
  data = steroids[steroids$n > 0, ]
)

## ----steroids-escalc-print----------------------------------------------------
head(steroids_es)

## ----steroids-fit-------------------------------------------------------------
fit_steroids <- cam(
  steroids_es,
  reference = "NIV",
  engine = "metafor"
)

## ----steroids-forest, fig.width = 8, fig.height = 6---------------------------
forestplot(fit_steroids, exponentiate = TRUE)

## ----il6-data-----------------------------------------------------------------
data(il6)
head(il6)

## ----il6-table----------------------------------------------------------------
table(il6$trial[il6$n > 0], il6$subgroup[il6$n > 0])

## ----il6-escalc---------------------------------------------------------------
il6_es <- escalc(
  measure = "OR",
  ai = treat.events,
  bi = treat.total - treat.events,
  ci = cont.events,
  di = cont.total - cont.events,
  data = il6[il6$n > 0, ]
)

## ----il6-escalc-print---------------------------------------------------------
head(il6_es)

## ----il6-fit------------------------------------------------------------------
fit_il6 <- cam(il6_es, reference = "no", engine = "metafor")

## ----il6-forest, fig.width = 10, fig.height = 6-------------------------------
forestplot(fit_il6, exponentiate = TRUE)

## ----respire-age-data---------------------------------------------------------
data(respire_age)
respire_age[, c("trial", "subgroup", "n", "hr", "ci_level", "yi", "vi")]

## ----respire-age-escalc-------------------------------------------------------
respire_age_es <- escalc(
  measure = "GEN",
  yi = respire_age$yi,
  vi = respire_age$vi,
  data = respire_age
)

## ----respire-age-fit, cache = TRUE--------------------------------------------
fit_respire_age <- cam(
  respire_age_es,
  reference = "<65",
  tau.prior = tau_m,
  tau.interaction.prior = tau_g
)

## ----respire-age-forest, fig.width = 8, fig.height = 6------------------------
forestplot(fit_respire_age, exponentiate = TRUE)

## ----respire-sex-data---------------------------------------------------------
data(respire_sex)
respire_sex[, c("trial", "subgroup", "n", "hr", "yi")]

## ----respire-sex-escalc-------------------------------------------------------
respire_sex_es <- escalc(
  measure = "GEN",
  yi = respire_sex$yi,
  vi = respire_sex$vi,
  data = respire_sex
)

## ----respire-sex-fit, cache = TRUE--------------------------------------------
fit_respire_sex <- cam(
  respire_sex_es,
  reference = "Male",
  tau.prior = tau_m,
  tau.interaction.prior = tau_g
)

## ----respire-sex-forest, fig.width = 8, fig.height = 6------------------------
forestplot(fit_respire_sex, exponentiate = TRUE)

