#' IL-6 antagonist COVID-19 mortality data (REACT meta-analysis)
#'
#' Event counts by trial and corticosteroid subgroup from the WHO REACT
#' prospective meta-analysis of IL-6 antagonists in patients hospitalized
#' for COVID-19. Some trials report only one corticosteroid subgroup
#' (`n = 0` in the other); drop those empty rows before [escalc()] and
#' let [ifrac()] / [cam()] complete the missing cells. See
#' `vignette("single-subgroup-trials")`.
#'
#' @format A data frame with 30 rows and 7 variables:
#' \describe{
#'   \item{trial}{Trial identifier.}
#'   \item{subgroup}{Corticosteroid subgroup (\code{yes} / \code{no}).}
#'   \item{n}{Total patients (`treat.total` + `cont.total`).}
#'   \item{treat.events}{Events in the treatment arm.}
#'   \item{treat.total}{Total subjects in the treatment arm.}
#'   \item{cont.events}{Events in the control arm.}
#'   \item{cont.total}{Total subjects in the control arm.}
#' }
#' @source
#' WHO Rapid Evidence Appraisal for COVID-19 Therapies (REACT) Working Group,
#' Sterne JAC, Murthy S, et al. (2021). Association between administration of
#' IL-6 antagonists and mortality among patients hospitalized for COVID-19:
#' a meta-analysis. \emph{JAMA}, 326(6), 499--518.
#' \url{https://doi.org/10.1001/jama.2021.11330}
#'
#' \url{https://pubmed.ncbi.nlm.nih.gov/34228774/}
#' @usage data(il6)
"il6"
